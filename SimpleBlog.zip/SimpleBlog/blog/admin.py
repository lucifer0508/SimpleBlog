from django.contrib import admin
from .models import Blogdata
# Register your models here.

admin.site.register(Blogdata)
